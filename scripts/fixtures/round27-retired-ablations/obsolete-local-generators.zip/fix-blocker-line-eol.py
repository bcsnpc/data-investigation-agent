from pathlib import Path
p=Path('docs/blockers-and-lessons.md');raw=p.read_bytes();needle=b'Round27 completion stale v2:';start=raw.index(needle);end=raw.index(b'\n',start)
line=raw[start:end];p.write_bytes(raw[:start]+line.rstrip(b' \t\r')+raw[end:])
print('Normalized one retained note; content preserved.')
