from pathlib import Path
import json
root=Path('scripts/investigator')
p=root/'nvidia_free_budget.py';s=p.read_text()
s=s.replace("    provider = 'nvidia'", "    provider = 'nvidia'\n    allowance = MONTHLY_CALLS\n    interval = INTERVAL\n    concurrency = CONCURRENCY\n    account_for = staticmethod(account_for)")
s=s.replace("provider != 'nvidia'", "provider != self.provider")
s=s.replace("        check_credit('nvidia',", "        check_credit(self.provider,")
a=s.index("        approved=policy('nvidia')");b=s.index("        if body.get('model')",a)
old=s[a:b]
check=old.replace("        approved=policy('nvidia')", "        from .provider_budget import policy\n        approved=policy(self.provider)")
s=s[:a]+"        self.check_policy()\n"+s[b:]
a=s.index('    def _reserve_attempt');s=s[:a]+"    def check_policy(self):\n"+check+'\n'+s[a:]
s=s.replace("'nvidia-free:' + str(uuid4())", "self.provider+'-free:' + str(uuid4())")
s=s.replace('account_for(self.clock())','self.account_for(self.clock())').replace('account_for(now) != account','self.account_for(now) != account')
s=s.replace('!= MONTHLY_CALLS', '!= self.allowance').replace('>= MONTHLY_CALLS','>= self.allowance')
# Revert module-level provision references; only instance accounting is dynamic.
s=s.replace("amount(row[1]) != self.allowance", "amount(row[1]) != MONTHLY_CALLS")
s=s.replace("active < CONCURRENCY", "active < self.concurrency").replace("active >= CONCURRENCY", "active >= self.concurrency")
s=s.replace("now + INTERVAL", "now + self.interval").replace("max(INTERVAL if", "max(self.interval if")
s=s.replace("'nvidia-free-queue'", "self.provider+'-free-queue'")
s=s.replace("'provider': 'nvidia'", "'provider': self.provider").replace("'label': 'nvidia-free'", "'label': self.provider+'-free'")
s=s.replace("'monthly_call_allowance': MONTHLY_CALLS", "'monthly_call_allowance': self.allowance")
p.write_text(s)
p=root/'adapters/reasoning_nvidia.py';s=p.read_text()
s=s.replace('started, secret_value):','started, secret_value, provider=\'nvidia\'):' )
s=s.replace("'provider':'nvidia','model':model", "'provider':provider,'model':model")
s=s.replace('class Client:\n', "class Client:\n    provider = 'nvidia'\n    base = BASE\n    budget_type = FreeBudget\n    request_for = staticmethod(request_for)\n    response_for = staticmethod(response_for)\n\n")
start=s.index('class Client:');a=s[:start];c=s[start:]
c=c.replace('isinstance(budget, FreeBudget)', 'isinstance(budget, self.budget_type)')
c=c.replace("'provider':'nvidia'", "'provider':self.provider").replace("'provider': 'nvidia'", "'provider': self.provider")
c=c.replace("BASE + '/", "self.base + '/")
c=c.replace('body = request_for(', 'body = self.request_for(').replace('reply = response_for(', 'reply = self.response_for(')
c=c.replace('secret_value=key)', 'secret_value=key,provider=self.provider)')
s=a+c;p.write_text(s)
p=root/'build_phase_policy.json';d=json.loads(p.read_bytes());d['round27']['providers']['openrouter']={
 'enabled':True,'unit':'CALLS_OR_MICRODOLLARS','free_daily_call_allowance':1000,
 'minimum_dispatch_interval_seconds':3,'maximum_concurrent_calls':2,
 'synthetic_only':True,'quality_scope':'DEV_ONLY','ceiling_microdollars':10000000,'warning_microdollars':8000000,
 'scope':'lifetime, never resets; remote key resets weekly but DIA does not',
 'paid_requires_all_free_tool_tests_failed':True,
 'allowed_purposes':['INTAKE','INVESTIGATOR','EVALUATOR','SCREENSHOT','SUMMARY','GRADING','SMOKE'],
 'approval':'Owner 2026-11-22: existing OpenRouter key, free first, conditional paid lifetime $10; no auto top-up'}
p.write_text(json.dumps(d,indent=2)+'\n')
for p in [root/'adapters/runtime_anthropic.py',root/'ai_steps.py',Path('scripts/cloud_guided_investigator.py')]:
 s=p.read_text();s=s.replace("from ..nvidia_free_budget import FreeRateCard, FreeBudget", "from ..provider_dev_budget import budget_types").replace("from .nvidia_free_budget import FreeRateCard, FreeBudget", "from .provider_dev_budget import budget_types").replace("from investigator.nvidia_free_budget import FreeRateCard, FreeBudget", "from investigator.provider_dev_budget import budget_types")
 s=s.replace("budget_type=FreeBudget if provider=='nvidia' else TicketBudget\n    rate_type=FreeRateCard if provider=='nvidia' else RateCard", "budget_type,rate_type=budget_types(config)")
 s=s.replace("budget_type=FreeBudget if config.get('provider')=='nvidia' else TicketBudget\n            rate_type=FreeRateCard if config.get('provider')=='nvidia' else RateCard", "budget_type,rate_type=budget_types(config)")
 s=s.replace("budget_type=FreeBudget if selected.get('provider')=='nvidia' else TicketBudget\n            rate_type=FreeRateCard if selected.get('provider')=='nvidia' else RateCard", "budget_type,rate_type=budget_types(selected)")
 s=s.replace("rate_type=FreeRateCard if investigator_configuration.get('provider')=='nvidia' else RateCard", "_,rate_type=budget_types(investigator_configuration)")
 p.write_text(s)
